import 'package:flutter/material.dart';

import '../stream_chat_flutter.dart';

class ReactionPicker extends StatelessWidget {
  const ReactionPicker({
    Key key,
    @required this.reactionToEmoji,
    @required this.message,
    @required this.channel,
    this.size = 40,
  }) : super(key: key);

  final Map<String, String> reactionToEmoji;
  final Message message;
  final double size;
  final Channel channel;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: reactionToEmoji.keys.map((reactionType) {
        final ownReactionIndex = message.ownReactions
            .indexWhere((reaction) => reaction.type == reactionType);
        return Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            IconButton(
              iconSize: size,
              icon: Text(
                reactionToEmoji[reactionType],
                style: TextStyle(
                  fontSize: size - 10,
                ),
              ),
              onPressed: () {
                if (ownReactionIndex != -1) {
                  removeReaction(context, reactionType);
                } else {
                  sendReaction(context, reactionType);
                }
              },
            ),
            ownReactionIndex != -1
                ? Padding(
                    padding: const EdgeInsets.only(bottom: 4.0),
                    child: Text(
                      message.ownReactions[ownReactionIndex].score.toString(),
                      style: TextStyle(color: Colors.white),
                    ),
                  )
                : SizedBox(),
          ],
        );
      }).toList(),
    );
  }

  void sendReaction(BuildContext context, String reactionType) {
    channel.sendReaction(message.id, reactionType);
    Navigator.of(context).pop();
  }

  void removeReaction(BuildContext context, String reactionType) {
    channel.deleteReaction(message.id, reactionType);
    Navigator.of(context).pop();
  }
}